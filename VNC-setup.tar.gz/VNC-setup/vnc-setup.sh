#!/bin/bash

#This script will install and configure a VNC server and the Xfce4 desktop environment for Linux
#Created February 2020
#Author: https://github.com/developerpiru/ 

echo "Updating libraries..."
sudo apt-get update -y
echo "Installing VNC components..."
sudo apt-get install xfce4 xfce4-goodies tightvncserver -y
echo "Starting VNC server..."
vncserver
echo "Killing VNC server to complete setup..."
vncserver -kill :1
echo "Configuring VNC server..."
sudo cp xstartup ~/.vnc/xstartup
sudo chmod +x ~/.vnc/xstartup
echo "All done!"
echo "The VNC server has now been installed. To start using it, you can enter: 'vncserver -geometry 1200x1050' where 1200x1050 is your preferred resolution"
echo "Install a VNC client on your local computer to connect to the VNC server. Try VNC Viewer for Windows, Mac and Linux"

